import { Header } from '@/components/header';
import { Hero } from '@/components/hero';
import { StatsSection } from '@/components/stats-section';
import { MissionVision } from '@/components/mission-vision';
import { CoreValues } from '@/components/core-values';
import { WhatWeDo } from '@/components/what-we-do';
import { Testimonials } from '@/components/testimonials';
import { ContactForm } from '@/components/contact-form';
import { Footer } from '@/components/footer';

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <StatsSection />
      <MissionVision />
      <CoreValues />
      <WhatWeDo />
      <Testimonials />
      <ContactForm />
      <Footer />
    </main>
  );
}
