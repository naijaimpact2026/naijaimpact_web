'use client';

import { Button } from '@/components/ui/button';

export function Hero() {
  return (
    <section id="home" className="relative min-h-[90vh] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-20 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-transparent -z-10" />
      
      {/* Decorative circles */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl -z-10 hidden md:block" />
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-secondary/10 rounded-full blur-3xl -z-10 hidden md:block" />

      <div className="max-w-6xl mx-auto w-full">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="animate-fade-in">
            <div className="inline-block mb-4">
              <span className="bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold">
                Welcome to our community
              </span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Unity in <span className="text-primary">Diversity</span>
            </h1>
            
            <p className="text-lg text-foreground/70 mb-8 leading-relaxed max-w-lg">
              Empowering communities through targeted training programs, accessible microfinance solutions, and quality education. Together, we create lasting positive change.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
                Get Started
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-primary/30 hover:bg-primary/5 text-primary font-semibold"
              >
                Learn More
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-6 pt-8 border-t border-primary/10">
              <div>
                <p className="text-3xl font-bold text-primary">1M+</p>
                <p className="text-sm text-foreground/60">People Trained</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">500K+</p>
                <p className="text-sm text-foreground/60">Loans Provided</p>
              </div>
            </div>
          </div>

          {/* Right Illustration - Club Image */}
          <div className="hidden md:flex items-center justify-center animate-scale-in">
            <div className="relative w-full max-w-md">
              {/* Animated shapes background */}
              <div className="absolute top-0 right-0 w-48 h-48 bg-primary/10 rounded-full blur-2xl animate-pulse-light -z-10" />
              
              {/* Club Image */}
              <img 
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-wR4AyL4XP0EOaXlWHmimCP88Kj1X6a.png"
                alt="Solidarity Empowerment Club - Unity in Diversity"
                className="w-full h-auto rounded-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
