import { Card } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';

export function WhatWeDo() {
  const programs = [
    {
      icon: '🎓',
      title: 'Skills Training',
      description: 'Comprehensive vocational and professional development programs designed to equip individuals with in-demand skills for employment.',
      features: ['Digital Literacy', 'Trade Skills', 'Professional Development'],
    },
    {
      icon: '💼',
      title: 'Microfinance Solutions',
      description: 'Accessible financial products that help entrepreneurs and small business owners grow their ventures and achieve financial independence.',
      features: ['Business Loans', 'Savings Schemes', 'Financial Literacy'],
    },
    {
      icon: '📖',
      title: 'Quality Education',
      description: 'Inclusive educational initiatives that provide quality learning opportunities for children and adults in underserved communities.',
      features: ['Scholarships', 'Mentorship', 'Adult Education'],
    },
    {
      icon: '🏥',
      title: 'Community Health',
      description: 'Health awareness and wellness programs that promote healthy living and access to basic health services.',
      features: ['Health Screening', 'Wellness Workshops', 'Health Education'],
    },
    {
      icon: '👩‍💼',
      title: 'Women Empowerment',
      description: 'Targeted initiatives to enhance economic and social empowerment of women through training and support programs.',
      features: ['Leadership Training', 'Income Generation', 'Mentoring'],
    },
    {
      icon: '🌍',
      title: 'Community Development',
      description: 'Grassroots projects that strengthen communities through infrastructure, social programs, and sustainable development initiatives.',
      features: ['Infrastructure', 'Social Programs', 'Sustainability'],
    },
  ];

  return (
    <section id="what-we-do" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            What We Do
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            Our comprehensive approach to empowerment spans training, finance, education, and community development
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {programs.map((program, index) => (
            <Card
              key={index}
              className="p-8 border-primary/20 hover:border-primary/50 transition-all duration-300 hover:shadow-xl group animate-scale-in"
              style={{
                animationDelay: `${index * 50}ms`,
              }}
            >
              <div className="flex items-start justify-between mb-4">
                <span className="text-4xl">{program.icon}</span>
                <ArrowRight size={20} className="text-primary opacity-0 group-hover:opacity-100 transition-opacity transform group-hover:translate-x-1" />
              </div>
              
              <h3 className="text-xl font-bold text-foreground mb-2">{program.title}</h3>
              <p className="text-foreground/60 mb-4 text-sm leading-relaxed">{program.description}</p>
              
              <div className="flex flex-wrap gap-2">
                {program.features.map((feature, idx) => (
                  <span
                    key={idx}
                    className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-medium hover:bg-primary/20 transition-colors cursor-default"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
