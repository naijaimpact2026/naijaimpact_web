import { Card } from '@/components/ui/card';

export function CoreValues() {
  const values = [
    {
      icon: '❤️',
      title: 'Compassion',
      description: 'We deeply care about the welfare and dignity of every person we serve, responding with genuine empathy and understanding.',
      color: 'from-primary/10 to-primary/5',
    },
    {
      icon: '🔍',
      title: 'Integrity',
      description: 'We operate with honesty, transparency, and accountability in all our dealings and relationships with stakeholders.',
      color: 'from-primary/10 to-primary/5',
    },
    {
      icon: '📚',
      title: 'Excellence',
      description: 'We pursue the highest standards in everything we do, continuously improving our programs and impact.',
      color: 'from-primary/10 to-primary/5',
    },
    {
      icon: '🌱',
      title: 'Sustainability',
      description: 'We focus on long-term solutions that create lasting change and environmental responsibility for future generations.',
      color: 'from-primary/10 to-primary/5',
    },
    {
      icon: '🤲',
      title: 'Accountability',
      description: 'We take responsibility for our actions and outcomes, ensuring our programs deliver measurable results.',
      color: 'from-primary/10 to-primary/5',
    },
    {
      icon: '🌐',
      title: 'Collaboration',
      description: 'We believe in partnerships and collective action to maximize impact and reach more communities effectively.',
      color: 'from-primary/10 to-primary/5',
    },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-primary/3 to-primary/1">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Our Core Values
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            These principles guide every decision we make and define who we are as an organization
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {values.map((value, index) => (
            <Card
              key={index}
              className={`p-8 border-primary/20 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 animate-slide-up group`}
              style={{
                animationDelay: `${index * 50}ms`,
              }}
            >
              <div className={`inline-flex items-center justify-center w-16 h-16 rounded-lg mb-6 bg-gradient-to-br ${value.color} group-hover:scale-110 transition-transform`}>
                <span className="text-3xl">{value.icon}</span>
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{value.title}</h3>
              <p className="text-foreground/60 leading-relaxed">{value.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
