import { Card } from '@/components/ui/card';
import { Star } from 'lucide-react';

export function Testimonials() {
  const testimonials = [
    {
      name: 'Chioma Okonkwo',
      role: 'Business Owner',
      location: 'Lagos',
      image: '👩‍💼',
      text: 'The microfinance support and business training I received transformed my small tailoring business into a thriving enterprise. I can now employ three other women and send my children to better schools.',
      rating: 5,
    },
    {
      name: 'Ahmed Hassan',
      role: 'Skills Training Graduate',
      location: 'Kano',
      image: '👨‍💻',
      text: 'Through the digital literacy program, I acquired skills that got me a job in a tech company. This opportunity changed my family\'s living conditions completely. I\'m grateful for the support.',
      rating: 5,
    },
    {
      name: 'Amara Nwankwo',
      role: 'Community Leader',
      location: 'Enugu',
      image: '👩‍🏫',
      text: 'SEC\'s community health initiative brought quality healthcare information to our rural community. The awareness programs have significantly improved health consciousness among residents.',
      rating: 5,
    },
    {
      name: 'Blessing Adeyemi',
      role: 'Women Empowerment Program',
      location: 'Ibadan',
      image: '👩‍🎓',
      text: 'The women empowerment program gave me the confidence and skills to start my own agricultural cooperative. Today, we serve over 200 families and our income has increased tenfold.',
      rating: 5,
    },
    {
      name: 'Marcus Ejiro',
      role: 'Scholarship Recipient',
      location: 'Port Harcourt',
      image: '🎓',
      text: 'As a scholarship recipient, I was able to complete my university education without the financial burden. Now I\'m working in my field and giving back to the community.',
      rating: 5,
    },
    {
      name: 'Fatima Muhammad',
      role: 'Youth Development Program',
      location: 'Katsina',
      image: '👩‍💪',
      text: 'SEC\'s youth development program provided me with entrepreneurship training and mentorship. I\'ve launched my own digital marketing business and employ five young people.',
      rating: 5,
    },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-secondary/5 to-transparent">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Success Stories
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            Hear from the people whose lives have been transformed by our programs and community support
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="p-6 border-primary/20 hover:border-primary/50 transition-all duration-300 hover:shadow-xl flex flex-col animate-slide-up group"
              style={{
                animationDelay: `${index * 50}ms`,
              }}
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className="fill-secondary text-secondary"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-foreground/70 mb-6 flex-grow leading-relaxed italic">
                "{testimonial.text}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4 pt-6 border-t border-primary/10">
                <div className="text-3xl">{testimonial.image}</div>
                <div>
                  <p className="font-bold text-foreground text-sm">{testimonial.name}</p>
                  <p className="text-xs text-foreground/60">{testimonial.role}</p>
                  <p className="text-xs text-primary font-medium">{testimonial.location}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
