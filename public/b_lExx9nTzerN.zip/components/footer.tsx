import { Mail, Phone } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background/90">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center mb-8">
          {/* Brand Section */}
          <div>
            <h3 className="font-bold text-lg text-background mb-2">
              Solidarity Empowerment Club
            </h3>
            <p className="text-background/70 text-sm">
              Unity in Diversity
            </p>
          </div>

          {/* Quick Links */}
          <div className="text-center">
            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <a href="#about" className="text-background/70 hover:text-background transition-colors">
                About
              </a>
              <a href="#what-we-do" className="text-background/70 hover:text-background transition-colors">
                Programs
              </a>
              <a href="#contact" className="text-background/70 hover:text-background transition-colors">
                Contact
              </a>
            </div>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col gap-2 md:text-right">
            <a href="mailto:info@solidarityclub.org" className="flex items-center gap-2 justify-center md:justify-end text-background/70 hover:text-background transition-colors text-sm">
              <Mail size={16} />
              info@solidarityclub.org
            </a>
            <a href="tel:+2341234567890" className="flex items-center gap-2 justify-center md:justify-end text-background/70 hover:text-background transition-colors text-sm">
              <Phone size={16} />
              +234 (0) 123-456-7890
            </a>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-background/10 pt-6">
          <p className="text-center text-sm text-background/70">
            &copy; {currentYear} Solidarity Empowerment Club. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
