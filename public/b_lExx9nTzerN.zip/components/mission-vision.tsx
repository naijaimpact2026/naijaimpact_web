import { Card } from '@/components/ui/card';

export function MissionVision() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Our Mission & Vision
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            Guided by our core principles, we work tirelessly to create sustainable change
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Mission Card */}
          <Card className="p-8 border-primary/20 hover:border-primary/50 transition-all duration-300 hover:shadow-xl animate-slide-up group">
            <div className="inline-flex items-center justify-center w-14 h-14 bg-primary/10 rounded-lg mb-6 group-hover:bg-primary/20 transition-colors">
              <span className="text-2xl">🎯</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Our Mission</h3>
            <p className="text-foreground/70 leading-relaxed mb-4">
              To empower underserved communities through comprehensive training programs, accessible microfinance solutions, and quality education that drives economic independence and social mobility.
            </p>
            <p className="text-foreground/60 text-sm">
              We believe every individual deserves the opportunity to develop skills, access capital, and build a better future for themselves and their families.
            </p>
          </Card>

          {/* Vision Card */}
          <Card className="p-8 border-secondary/20 hover:border-secondary/50 transition-all duration-300 hover:shadow-xl animate-slide-up group" style={{ animationDelay: '100ms' }}>
            <div className="inline-flex items-center justify-center w-14 h-14 bg-secondary/10 rounded-lg mb-6 group-hover:bg-secondary/20 transition-colors">
              <span className="text-2xl">🌟</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Our Vision</h3>
            <p className="text-foreground/70 leading-relaxed mb-4">
              A prosperous and equitable society where communities are empowered with knowledge, skills, and resources to overcome challenges and achieve sustainable economic growth.
            </p>
            <p className="text-foreground/60 text-sm">
              Unity in diversity is not just our slogan—it&apos;s our commitment to bringing people from all backgrounds together for collective progress.
            </p>
          </Card>
        </div>

        {/* Key Principles */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center p-6 rounded-lg bg-gradient-to-br from-primary/5 to-transparent hover:from-primary/10 transition-all duration-300 animate-scale-in">
            <div className="text-4xl mb-3">🤝</div>
            <h4 className="font-bold text-foreground mb-2">Solidarity</h4>
            <p className="text-sm text-foreground/60">Standing together in support and mutual aid for community welfare</p>
          </div>
          <div className="text-center p-6 rounded-lg bg-gradient-to-br from-secondary/5 to-transparent hover:from-secondary/10 transition-all duration-300 animate-scale-in" style={{ animationDelay: '100ms' }}>
            <div className="text-4xl mb-3">💪</div>
            <h4 className="font-bold text-foreground mb-2">Empowerment</h4>
            <p className="text-sm text-foreground/60">Providing tools, knowledge, and resources for self-determination</p>
          </div>
          <div className="text-center p-6 rounded-lg bg-gradient-to-br from-primary/5 to-secondary/5 hover:from-primary/10 hover:to-secondary/10 transition-all duration-300 animate-scale-in" style={{ animationDelay: '200ms' }}>
            <div className="text-4xl mb-3">🌍</div>
            <h4 className="font-bold text-foreground mb-2">Inclusion</h4>
            <p className="text-sm text-foreground/60">Embracing diversity and ensuring no one is left behind</p>
          </div>
        </div>
      </div>
    </section>
  );
}
