'use client';

import { useEffect, useState, useRef } from 'react';

interface StatProps {
  value: number;
  suffix: string;
  label: string;
  icon: string;
}

function AnimatedStat({ value, suffix, label, icon }: StatProps) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsVisible(true);
        observer.unobserve(entry.target);
      }
    });

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const increment = value / 50;
    const interval = setInterval(() => {
      setCount((prev) => {
        const next = prev + increment;
        return next >= value ? value : next;
      });
    }, 30);

    return () => clearInterval(interval);
  }, [isVisible, value]);

  return (
    <div ref={ref} className="text-center p-6 rounded-xl bg-card border border-primary/10 hover:border-primary/30 transition-all duration-300 hover:shadow-lg animate-slide-up">
      <div className="text-4xl mb-3">{icon}</div>
      <p className="text-3xl md:text-4xl font-bold text-primary mb-2">
        {Math.round(count).toLocaleString()}
        <span className="text-secondary text-2xl">{suffix}</span>
      </p>
      <p className="text-foreground/60 font-medium">{label}</p>
    </div>
  );
}

export function StatsSection() {
  const stats = [
    { value: 1000000, suffix: '+', label: 'People Trained', icon: '👥' },
    { value: 500000, suffix: '+', label: 'Loans Provided', icon: '💰' },
    { value: 774, suffix: '', label: 'LGAs Reached', icon: '🗺️' },
    { value: 50000, suffix: '+', label: 'Lives Transformed', icon: '✨' },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-primary/5 to-secondary/5">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Our Impact by Numbers
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            Real results from our dedicated efforts to empower communities across the region
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              style={{
                animationDelay: `${index * 100}ms`,
              }}
            >
              <AnimatedStat {...stat} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
